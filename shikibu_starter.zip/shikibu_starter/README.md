# Shikibu

Nuenagon（αβ探索エンジン）用評価関数 RayPair の学習器。設計書は `docs/DESIGN.md`。

- `docs/`、`reference/`、`tests/`、`PROTECTED.sha256`、`check_protected.py` は変更禁止。
- 確認：`python check_protected.py`

あなたは将棋AI用評価関数の学習器「Shikibu」の、最初の部品（マイルストーン M1）を実装する担当です。
仕様は `docs/DESIGN.md` にあります。必要なのは主に **第F部（凍結区画）** と **§S1・§S2・§S8** です。第E部（エンジン）は読まなくてよいです。

## やること（M1 だけ）

Rust で特徴抽出ライブラリを作り、pyo3 + maturin で Python モジュール `shikibu_feat` としてビルドする。次の4関数を公開すること。

```
num_features(version: int) -> int
extract_sfen(sfen: str, perspective: int, version: int) -> list[int]   # 昇順・重複込み
decode_psv(rec: bytes) -> tuple[str, int, int, int, int]             # (sfen, score, move, gamePly, game_result)
extract_psv(rec: bytes, perspective: int, version: int) -> list[int]  # 昇順・重複込み
```

- perspective：0 = 先手視点、1 = 後手視点。version：0 = RayPair_v0、1 = RayPair_v1。
- 置き場所：`crates/shk_feat/`（Rust のクレート）。ビルド手順を `README.md` に書く。
- PackedSfen（PSV の先頭32バイト）のデコーダは自作する。形式はやねうら王の PackedSfen。正解は cshogi の `Board.set_psfen` と一致すること（テストで確認される）。
- 既存の将棋NNUE実装（やねうら王、bullet、bullet-shogi、tatara など）のコードはコピーしないこと。

## 合格条件

```
pip install cshogi pytest numpy maturin
maturin develop --release -m crates/shk_feat/Cargo.toml
python -m pytest -q tests
```

がすべて通ること。テストは私が用意した完成品で、`tests/test_m1_acceptance.py` に API と判定内容が書いてある。

## 変更禁止（最重要）

次のファイルは**1文字も変更・削除・移動してはいけない**。

- `docs/DESIGN.md`
- `reference/raypair_ref.py`
- `tests/` 以下のすべて（`golden/raypair_golden.json` を含む）
- `PROTECTED.sha256`、`check_protected.py`

テストが通らないときは、**必ず実装側を直す**こと。期待値やテストを書き換えたり、テストをスキップ・無効化したりするのは禁止。もし「テストか設計書の方が間違っている」と思ったら、直さずに作業を止めて報告すること。

## 進め方

1. まず `docs/DESIGN.md` の第F部と `reference/raypair_ref.py` を読む。参照実装は遅いが正しい。Rust 版はこれと同じ結果を出せばよい。
2. 実装は「SFEN を読む → 盤面 → 特徴抽出」から作り、`test_golden` を通す。次に PSV のデコーダを作り、残りのテストを通す。
3. コミットは小さく分ける。各コミットの前に `python check_protected.py` を実行し、OK であることを確認する。
4. 高速化は不要。正しさだけを目指す（速度は M2 で別の担当が扱う）。

## すぐに作業をやめる条件（早めに投げ出してよい。むしろそうしてほしい）

次のどれかに当てはまったら、それ以上粘らずに作業を止め、下の「報告」を書いて終了すること。無理に続けるより、早く止めてくれる方がありがたい。

1. **ビルドが通らない**：Rust + pyo3 + maturin のビルド環境が、3回試しても作れない。
2. **同じ失敗を繰り返す**：同じテストの失敗を、方針を変えて3回直そうとしても通らない。
3. **全体が長引いている**：ツール呼び出しが合計60回を超えても、`test_golden` が全部通っていない。
4. **仕様の解釈に迷った**：第F部の書き方が2通りに読めて、どちらが正しいか参照実装を見ても決められない。
5. **変更禁止のファイルを触りたくなった**：テストや正解データを変えないと通らないように見えた。
6. **想定外の大きな作業が必要になった**：例えば M1 の範囲を超える設計変更が要りそうだと感じた。

## 報告（終了時に必ず書く。成功・中断どちらでも）

`REPORT_M1.md` に次をまとめてコミットし、同じ内容を最後のメッセージにも書くこと。

- 結果：完了 ／ 中断（中断ならどの条件に当たったか）
- `python -m pytest -q tests` の最終出力（何件通り、何件落ちたか）
- 落ちているテストがあれば、その名前と、原因の見立て
- 作ったファイルの一覧と、それぞれの役割（1行ずつ）
- ビルド手順
- 次の担当への引き継ぎ事項（未完了の作業、気づいた点）
- `python check_protected.py` の結果
